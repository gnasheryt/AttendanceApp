package com.gnasher.attendance;

import android.app.Application;

import com.parse.Parse;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("2OsKRaDOmiJzFPCL0Ru6dYDmpwr8XaTtwGPuRtI0")
                // if defined
                .clientKey("LHKnthxZQFhkQd5iqTyaiyLhzn669qJZdOuLxeCa")
                .server("https://parseapi.back4app.com/")
                .build()
        );
    }
}
