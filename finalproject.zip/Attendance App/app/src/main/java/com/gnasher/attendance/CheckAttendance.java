package com.gnasher.attendance;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;
import com.shashank.sony.fancytoastlib.FancyToast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class CheckAttendance extends AppCompatActivity {
    CheckedTextView roll;
    ArrayList<String> selectedItems;
    TextView stringTextView;
    ParseUser parseUser;
    Spinner selectDepart, selectYear;
    SimpleDateFormat dateFormat;
    String curDate;
    Calendar calendar;
    private ListView listView;
    private ArrayList<String> tDate,presentStud;
    private ArrayAdapter adapter;
    ParseObject checkAttendnaceObject;
    Spinner sub;
    String currentDateandTime,checkSubjects;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_attendance);
        selectedItems = new ArrayList<String>();
        roll = findViewById(R.id.txt_title);
        selectDepart = findViewById(R.id.depart);
        selectYear = findViewById(R.id.year);
        parseUser = ParseUser.getCurrentUser();
        calendar = Calendar.getInstance();
        curDate = dateFormat.getDateInstance().format(calendar.getTime());
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        currentDateandTime = sdf.format(new Date());


        tDate = new ArrayList<>();
        presentStud=new ArrayList<>();
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_checked, presentStud);

//        listView.setOnItemClickListener(this);
        // stringTextView=findViewById(R.id.textView);

        sub = findViewById(R.id.selectSubject);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.subjects, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sub.setAdapter(adapter);
        checkSubjects=(String) sub.getSelectedItem();

        try {

            listView = (ListView) findViewById(R.id.checkable_list);
            //set multiple selection mode
            listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
           // listView.setOnItemClickListener(this);
            String[] items = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"};
            //supply data itmes to ListView
            ArrayAdapter<String> aa = new ArrayAdapter<String>(this, R.layout.rowlayout, R.id.txt_title, items);
            listView.setAdapter(aa);
            //set OnItemClickListener
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    // selected item
                    String selectedItem = ((TextView) view).getText().toString();
                    if (selectedItems.contains(selectedItem)) {
                        selectedItems.remove(selectedItem); //remove deselected item from the list of selected items

                    } else
                        selectedItems.add(selectedItem); //add selected item to the list of selected items
                    //use selectedItem to get text
                    //Toast.makeText(CheckAttendance.this, selectedItem, Toast.LENGTH_LONG).show();
//                for(int i=0; i < selectedItems.size(); i++){
//
//                    Toast.makeText(CheckAttendance.this, selectedItems.get(i) + " , ", Toast.LENGTH_LONG).show();
//
//                    stringTextView.setText(stringTextView.getText() + selectedItems.get(i) + " , ");
                    //}
                }


            });
/*
                // code starts
            ParseQuery<ParseUser> query = ParseUser.getQuery();
          //  query.whereNotEqualTo("username", ParseUser.getCurrentUser().getUsername());
            query.whereEqualTo("Date",curDate);
            query.findInBackground(new FindCallback<ParseUser>() {
                @Override
                public void done(List<ParseUser> objects, ParseException e) {
                    if (objects.size() > 0 && e == null) {

                        for (ParseUser twitterUser : objects) {

                            tUsers.add(selectedItems.toString());
                        }
                        listView.setAdapter(adapter);

                        for (String twitterUser : tUsers) {

                            if (ParseUser.getCurrentUser().getList("PresentedStudents") != null) {
                                if (ParseUser.getCurrentUser().getList("PresentedStudents").contains(twitterUser)) {

                                    listView.setItemChecked(tUsers.indexOf(twitterUser), true);

                                }
                            }
                        }

                    }
                }
            });
*/
        } catch (Exception e) {

            e.getMessage();


        }


    }


        /*
        r1=findViewById(R.id.r1);
        r1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(r1.isChecked())
                {
                    r1.setChecked(false);
                }
                else
                {
                    r1.setChecked(true);
                }
            }
        });*/
        String selItems="";

    public void showSelectedItems(View view) {
     //   String selItems = "";
        for (String item : selectedItems) {
            if (selItems == "")
                selItems = item;
            else
                selItems += "," + item;
        }
       // Toast.makeText(this, selItems, Toast.LENGTH_LONG).show();
        // ParseObject attendanceObject = new ParseObject("Attendance");
        checkAttendnaceObject = new ParseObject("PresentOn");



/*
        try{
            ParseQuery query=new ParseQuery("PresentOn");
            query.addDescendingOrder("date");
            query.findInBackground(new FindCallback<ParseObject>() {
                @Override
                public void done(List<ParseObject> objects, ParseException e) {
                    if (objects.size() > 0 && e == null) {
                        for (ParseObject tweetObject : objects) {
                            if(parseUser.getString("date")==curDate){
                                parseUser.getList("date").remove(curDate);
                                parseUser.getList("presenties").remove(selItems);
                                List currentDate = checkAttendnaceObject.getList("date");
                               List currentPresent = checkAttendnaceObject.getList("presenties");
                               checkAttendnaceObject.remove("date");
                              checkAttendnaceObject.remove("presenties");
                              parseUser.put("date", currentDate);
                              parseUser.put("presenties", currentPresent);
                              parseUser.put("subjects", checkSubjects);
                             }else{
                             parseUser.put("date", curDate);
                            parseUser.put("presenties", selItems);
                             parseUser.put("subjects", checkSubjects);

        }




                        }



                    }
                }
            });

        }catch (Exception e){
            e.printStackTrace();
        }
*/

        /*
        if(tweetObject.getString("date").contains(curDate)){
                                parseUser.getList("date").remove(curDate);
                                parseUser.getList("presenties").remove(selItems);
                                 List currentDate = parseUser.getList("date");
                                  List currentPresent = parseUser.getList("presenties");
                                parseUser.remove("date");
                                parseUser.remove("presenties");
                                parseUser.put("date", curDate);
                                parseUser.put("presenties", selItems);
                            }else{
                                parseUser.put("date", curDate);
                                parseUser.put("presenties", selItems);

                            }
 */



 // TODO code to replace a object
/*
        if(checkAttendnaceObject.getString("date")==curDate){
            checkAttendnaceObject.getList("date").remove(curDate);
            checkAttendnaceObject.getList("presenties").remove(selItems);
            checkAttendnaceObject.getList("subjects").remove(checkSubjects);
            List currentDate = checkAttendnaceObject.getList("date");
            List currentPresent = checkAttendnaceObject.getList("presenties");
            checkAttendnaceObject.remove("date");
            checkAttendnaceObject.remove("presenties");
            checkAttendnaceObject.put("date", currentDate);
            checkAttendnaceObject.put("presenties", currentPresent);
            checkAttendnaceObject.put("subjects", checkSubjects);
        }else{
            checkAttendnaceObject.getList("date").remove(curDate);
            checkAttendnaceObject.getList("presenties").remove(selItems);
            checkAttendnaceObject.getList("subjects").remove(checkSubjects);
            checkAttendnaceObject.put("date", curDate);
            checkAttendnaceObject.put("presenties", selItems);
            checkAttendnaceObject.put("subjects", checkSubjects);

        }
*/

/*

        if(checkAttendnaceObject.getString("date")==curDate){
            parseUser.getList("date").remove(curDate);
            parseUser.getList("presenties").remove(selItems);
            parseUser.getList("subjects").remove(checkSubjects);
            List currentDate = parseUser.getList("date");
            List currentPresent = parseUser.getList("presenties");
            parseUser.remove("date");
            parseUser.remove("presenties");
            parseUser.put("date", currentDate);
            parseUser.put("presenties", currentPresent);
            parseUser.put("subjects", checkSubjects);
        }else{
            parseUser.getList("date").remove(curDate);
            parseUser.getList("presenties").remove(selItems);
            parseUser.getList("subjects").remove(checkSubjects);
            parseUser.put("date", curDate);
            parseUser.put("presenties", selItems);
            parseUser.put("subjects", checkSubjects);

        }

*/
        // TODO main transfer to database

       checkAttendnaceObject.put("date", curDate);
       checkAttendnaceObject.put("presenties", selItems);
        checkAttendnaceObject.put("subjects", sub.getSelectedItem());


      //array one
        //
        //checkAttendnaceObject.put("PresentStudents", selectedItems);



















//        checkAttendnaceObject.getList("date").remove(curDate);
//        checkAttendnaceObject.getList("PresentStudents").remove(selectedItems);
//        List currentDate = checkAttendnaceObject.getList("date");
//        List currentPresent = checkAttendnaceObject.getList("PresentStudents");
//        checkAttendnaceObject.remove("date");
//        checkAttendnaceObject.remove("PresentStudents");
//        checkAttendnaceObject.put("date", curDate);
//        checkAttendnaceObject.put("PresentStudents", selectedItems);

        /*

try {
    ParseQuery<ParseUser> query = ParseUser.getQuery();
    //  query.whereNotEqualTo("username", ParseUser.getCurrentUser().getUsername());
    query.whereEqualTo("Date", curDate);
    query.findInBackground(new FindCallback<ParseUser>() {
        @Override
        public void done(List<ParseUser> objects, ParseException e) {

               for (ParseUser twitterUser : objects) {

                   tDate.add(curDate);
                   presentStud.add(selectedItems.toString());
               }
            for (String twitterUser : tDate) {

                if (tDate.contains(curDate)) {

                    checkAttendnaceObject.put("date", curDate);
                    checkAttendnaceObject.put("PresentStudents", selectedItems);
                } else {
                    checkAttendnaceObject.getList("date").remove(curDate);
                    checkAttendnaceObject.getList("PresentStudents").remove(selectedItems);

                    // ParseUser.getCurrentUser().getList("fanOf").remove(tUsers.get(position));
                    //   List currentUserFanOfList = ParseUser.getCurrentUser().getList("fanOf");
                    List currentDate = checkAttendnaceObject.getList("date");
                    List currentPresent = checkAttendnaceObject.getList("PresentStudents");
                    ParseUser.getCurrentUser().remove("fanOf");
                    checkAttendnaceObject.remove("date");
                    checkAttendnaceObject.remove("PresentStudents");
                    checkAttendnaceObject.put("date", curDate);
                    checkAttendnaceObject.put("PresentStudents", selectedItems);
                }

            }
        }
    });

}catch (Exception e){e.printStackTrace();}



         */
//        checkAttendnaceObject.put("date", curDate);
//        checkAttendnaceObject.put("PresentStudents", selectedItems);
        final ProgressDialog progressDialog=new ProgressDialog(CheckAttendance.this);

        //used to show the dialog box

        progressDialog.setMessage("Updating the info ");
        progressDialog.show();
        parseUser.saveInBackground();

        checkAttendnaceObject.saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {
                if(e==null){
                    FancyToast.makeText(CheckAttendance.this,"Saved the attendance",FancyToast.LENGTH_LONG,FancyToast.INFO,true).show();
                  Intent in=new Intent(CheckAttendance.this,MainActivity.class);
                  startActivity(in);
                }else {
                    FancyToast.makeText(CheckAttendance.this,e.getMessage(),FancyToast.LENGTH_LONG,FancyToast.ERROR,true).show();
                }
            }
        });
        progressDialog.dismiss();
    }


        /*
        for(int i=0;selectYear==attendanceObject.get("Year");i++)
        {
            for(int j=0;selectDepart==attendanceObject.get("Branch");j++){
                for(int k=0;curDate==checkAttendnaceObject.get("Date");k++)
                {
                    checkAttendnaceObject.put("PresentStudents",selItems);
                }
            }
        }*/
        /*
        try {
            ParseQuery<ParseUser> query = ParseUser.getQuery();

//                //  query.whereNotEqualTo("username", ParseUser.getCurrentUser().getUsername());
//                query.whereEqualTo("Date",curDate);
//                tUsers.add(selItems);

            // checkAttendnaceObject.put("PresentStudents", selectedItems);

                query.findInBackground(new FindCallback<ParseUser>() {
                    @Override
                    public void done(List<ParseUser> objects, ParseException e) {
                        for (ParseUser twitterUser : objects) {

                            tUsers.add(selectedItems.toString());
                        }
                        for (String date : tUsers) {

                            if (checkAttendnaceObject.getList("PresentedStudents") != null) {
                                if (checkAttendnaceObject.getList("PresentedStudents").contains(curDate)) {

                                    checkAttendnaceObject.put("PresentStudents", selectedItems);

                                }
                            }
                        }
                    }
                });


        } catch (Exception e) {
            e.printStackTrace();
        }*/


//checkAttendnaceObject.add("PresentStudents", selectedItems);


//        if(checkAttendnaceObject.get("Date").equals(curDate)) {
//
//
//            checkAttendnaceObject.add("PresentStudents", selectedItems);
//
//
//        }














       // checkAttendnaceObject.hasSameId("Date");

        /*
        if(selectYear==attendanceObject.get("Year"))
        {
            if(selectDepart==attendanceObject.get("Branch")){
                if(curDate==checkAttendnaceObject.get("Date"))
                {
                    checkAttendnaceObject.put("TestPresent",selItems);
                }

            }
        }*/
       // parseUser.put("Present",selectedItems);



/*
    @Override
    public void onItemClick(AdapterView<?> parent
            , View view, int position, long id) {

        CheckedTextView checkedTextView =  (CheckedTextView) view;
       // checkAttendnaceObject.put("date", curDate);
//                checkAttendnaceObject.put("PresentStudents", selectedItems);

        if (checkedTextView.isChecked()) {

          //  FancyToast.makeText(CheckAttendance.this, tUsers.get(position) + " is now followed!", Toast.LENGTH_SHORT, FancyToast.INFO, true).show();
            checkAttendnaceObject.put("date", curDate);
               checkAttendnaceObject.put("PresentStudents", selectedItems);
        } else {

           // FancyToast.makeText(CheckAttendance.this, tUsers.get(position) + " is now unfollowed!", Toast.LENGTH_SHORT, FancyToast.INFO, true).show();

               checkAttendnaceObject.getList("date").remove(curDate);
               checkAttendnaceObject.getList("PresentStudents").remove(selectedItems);

           // ParseUser.getCurrentUser().getList("fanOf").remove(tUsers.get(position));
         //   List currentUserFanOfList = ParseUser.getCurrentUser().getList("fanOf");
            List currentDate=checkAttendnaceObject.getList("date");
            List currentPresent=checkAttendnaceObject.getList("PresentStudents");
            ParseUser.getCurrentUser().remove("fanOf");
            checkAttendnaceObject.remove("date");
            checkAttendnaceObject.remove("PresentStudents");
            checkAttendnaceObject.put("date", curDate);
            checkAttendnaceObject.put("PresentStudents", selectedItems);
           // ParseUser.getCurrentUser().put("fanOf", currentUserFanOfList);

        }
        checkAttendnaceObject.saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {
                if (e == null) {

                    FancyToast.makeText(CheckAttendance.this, "Saved", Toast.LENGTH_SHORT,
                            FancyToast.SUCCESS, true).show();
                }
                else {
                    e.printStackTrace();
                }
            }
        });
    }*/
}
