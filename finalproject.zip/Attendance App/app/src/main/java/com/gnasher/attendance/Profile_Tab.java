package com.gnasher.attendance;


import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.gnasher.attendance.R;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SaveCallback;
import com.shashank.sony.fancytoastlib.FancyToast;


/**
 * A simple {@link Fragment} subclass.
 */
public class Profile_Tab extends Fragment {


    private EditText editProfile,editBio,editProfession,editHobbies,editSports;
    private Button updateProfile;

    public Profile_Tab() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_profile__tab, container, false);
        editProfile=view.findViewById(R.id.profileName);
        editBio=view.findViewById(R.id.bio);
        editProfession=view.findViewById(R.id.profession);
        editHobbies=view.findViewById(R.id.hobbies);
        editSports=view.findViewById(R.id.sports);
        updateProfile=view.findViewById(R.id.update);

        //used to get current user
        final ParseUser parseUser=ParseUser.getCurrentUser();

        //used to set the preentered value
        editProfile.setText(parseUser.get("profileName").toString());
        editBio.setText(parseUser.get("profileBio").toString());
        editProfession.setText(parseUser.get("profileProfession").toString());
        editHobbies.setText(parseUser.get("profileHobbies").toString());
        editSports.setText(parseUser.get("profileSports").toString());


        //Updating the values
        updateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            parseUser.put("profileName",editProfile.getText().toString());
            parseUser.put("profileBio",editBio.getText().toString());
            parseUser.put("profileProfession",editProfession.getText().toString());
            parseUser.put("profileHobbies",editHobbies.getText().toString());
            parseUser.put("profileSports",editSports.getText().toString());

                final ProgressDialog progressDialog=new ProgressDialog(getContext());

                //used to show the dialog box

                progressDialog.setMessage("Updating the info ");
                progressDialog.show();
                //used to save the values in database in background
                parseUser.saveInBackground(new SaveCallback() {
                    @Override
                    public void done(ParseException e) {
                        if(e==null){
                            FancyToast.makeText(getContext(),"Updated the INFO",FancyToast.LENGTH_LONG,FancyToast.INFO,true).show();
                        }else {
                            FancyToast.makeText(getContext(),e.getMessage(),FancyToast.LENGTH_LONG,FancyToast.ERROR,true).show();
                        }

                    }
                });
                progressDialog.dismiss();
            }
        });

        return view;
    }

}
