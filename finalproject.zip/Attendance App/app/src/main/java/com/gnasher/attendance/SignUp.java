package com.gnasher.attendance;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

public class SignUp extends AppCompatActivity {

    private EditText editEmail;
     private EditText editUser;
     private EditText editPass;
      private Button btnsignup;
     private Button btnLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        setTitle("Sign Up");

        editEmail=findViewById(R.id.editEmail);
        editUser=findViewById(R.id.editUserName);
        editPass=findViewById(R.id.editPass);
        btnsignup=findViewById(R.id.BtnSign);
        btnLogin=findViewById(R.id.BtnLogin);

        editPass.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if(keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN){
                    onClick(btnsignup);
                }
                return false;
            }


        });



        if(ParseUser.getCurrentUser()!=null){
//            ParseUser.getCurrentUser().logOut();
            transitiontoSocailMediaActivity();
        }





        btnLogin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(SignUp.this,SignUpLogin.class);
                startActivity(in);
            }
        });
    }

    private void onClick(Button btnsignup) {
        btnsignup.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                if(editEmail.getText().toString().equals("")||editUser.getText().toString().equals("")||editPass.getText().toString().equals("")){
                    Toast.makeText(SignUp.this,"Email , User Name , Password is required ",Toast.LENGTH_LONG).show();
                }else {
                    final ParseUser appUser=new ParseUser();
                    appUser.setUsername(editUser.getText().toString());
                    appUser.setEmail(editEmail.getText().toString());
                    appUser.setPassword(editPass.getText().toString());
                    final ProgressDialog progressDialog=new ProgressDialog(SignUp.this);

                    progressDialog.setMessage("Signing Up "+ editUser.getText().toString());
                    progressDialog.show();
                    appUser.signUpInBackground(new SignUpCallback() {
                        @Override
                        public void done(ParseException e) {
                            if(e==null){

                                Toast.makeText(SignUp.this,appUser.get("username") +" is signed up successfully",Toast.LENGTH_LONG).show();
//                                Intent in=new Intent(SignUp.this,WelcomeActivity.class);
//                                startActivity(in);
                                transitiontoSocailMediaActivity();
                            }else{
                                Toast.makeText(SignUp.this, e.getMessage(),Toast.LENGTH_LONG).show();

                            }
                            progressDialog.dismiss();
                        }
                    });
                }
            }
        });
    }

    public void rootLayout(View  view){
        try {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void transitiontoSocailMediaActivity(){
        Intent in=new Intent(SignUp.this,MainActivity.class);
        startActivity(in);
    }

}

