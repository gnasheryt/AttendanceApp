package com.gnasher.attendance;

        import android.app.ProgressDialog;
        import android.content.Intent;
        import android.os.Bundle;
        import android.os.PersistableBundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;

        import androidx.annotation.Nullable;
        import androidx.appcompat.app.AppCompatActivity;

        import com.parse.LogInCallback;
        import com.parse.ParseException;
        import com.parse.ParseUser;
        import com.parse.SignUpCallback;

public class SignUpLogin extends AppCompatActivity {

    private EditText editNameLogin,editPassLogin;
    private Button btnsign,btnlogin;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_login);
        // editNameSign=findViewById(R.id.editName);
        // editPassSign=findViewById(R.id.editPass);
        editNameLogin=findViewById(R.id.editUserLogin);
        editPassLogin=findViewById(R.id.editPasswordLogin);
       // btnsign=findViewById(R.id.BtnSign);
        btnlogin=findViewById(R.id.login);

/*
        btnsign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                final ParseUser appUser=new ParseUser();
//                appUser.setUsername(editNameSign.getText().toString());
//                appUser.setPassword(editPassSign.getText().toString());
//                appUser.signUpInBackground(new SignUpCallback() {
//                    @Override
//                    public void done(ParseException e) {
//                        if(e==null){
//
//                            Toast.makeText(SignUpLogin.this,appUser.get("username") +" is signed up successfully",Toast.LENGTH_LONG).show();
//                            Intent in=new Intent(SignUpLogin.this,WelcomeActivity.class);
//                            startActivity(in);
//                        }else{
//                            Toast.makeText(SignUpLogin.this, e.getMessage(),Toast.LENGTH_LONG).show();
//
//                        }
//                    }
//                });

                Intent in=new Intent(SignUpLogin.this,SignUp.class);
                startActivity(in);


            }
        });
*/
        if(ParseUser.getCurrentUser()!=null){
//            ParseUser.getCurrentUser().logOut();
            transitiontoSocailMediaActivity();
        }

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editNameLogin.getText().toString().equals("") || editPassLogin.getText().toString().equals(""))
                {
                    Toast.makeText(SignUpLogin.this,"User Name , Password is required ",Toast.LENGTH_LONG).show();

                }
                else{
                    ParseUser.logInInBackground(editNameLogin.getText().toString(), editPassLogin.getText().toString(), new LogInCallback() {
                        @Override
                        public void done(ParseUser user, ParseException e) {


                            if (user != null && e == null) {
                                Toast.makeText(SignUpLogin.this, user.get("username") + " is Logged in successfully", Toast.LENGTH_LONG).show();
//                                Intent in = new Intent(SignUpLogin.this, WelcomeActivity.class);
//                                startActivity(in);
                                transitiontoSocailMediaActivity();
                            } else {
                                Toast.makeText(SignUpLogin.this, e.getMessage(), Toast.LENGTH_LONG).show();

                            }

                        }
                    });
                }
            }
        });


    }
    private void transitiontoSocailMediaActivity(){
        Intent in=new Intent(SignUpLogin.this,MainActivity.class);
        startActivity(in);
    }
}
