package com.gnasher.attendance;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class ViewAttendance extends CheckAttendance {
    ParseUser parseUser;
    Spinner selectDepart,selectYear;
    SimpleDateFormat dateFormat;
    String curDate;
    Calendar calendar;
ListView viewTweetsListView;
    TextView viewDate,viewAttendance;
    String getDate,getPresent;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_attend);
         ParseUser parseUser=ParseUser.getCurrentUser();
        final ParseObject checkAttendnaceObject = new ParseObject("PresentOn");
        viewAttendance=findViewById(R.id.viewStudents);
        viewDate=findViewById(R.id.viewDate);
        selectYear=findViewById(R.id.year);
       // viewTweetsListView=findViewById(R.id.viewTweetsListView);
        calendar = Calendar.getInstance();
        curDate=dateFormat.getDateInstance().format(calendar.getTime());
       // viewAttendance.setText("1234152523");
//        viewDate.setText(ParseUser.getCurrentUser().get("date").toString());
        try{
        ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery("PresentOn");
      //  parseQuery.whereEqualTo("Date","Present");

        parseQuery.addAscendingOrder("Date");

        parseQuery.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                if(objects.size()>0)
                {
                    if(e==null){
                        for(ParseObject object:objects ){
                            getDate=ParseUser.getCurrentUser().get("date").toString();
                            getPresent=ParseUser.getCurrentUser().getString("PresentStudents");
                           // viewDate.setText(ParseUser.getCurrentUser().get("date").toString());
                           // viewAttendance.setText(checkAttendnaceObject.getList("PresentStudents").toString());
                           // checkAttendnaceObject.getList("PresentStudents").toString();
                        }
                    }
                }
            }
        });
 // TODO main fetching files

//            getDate=checkAttendnaceObject.getList("date").toString();
//            getPresent=checkAttendnaceObject.getList("PresentStudents").toString();
//            getDate=checkAttendnaceObject.getString("date");
//            getPresent=checkAttendnaceObject.getString("PresentStudents");
//            viewDate.setText(getDate);
//            viewAttendance.setText(getPresent);

            viewDate.setText(checkAttendnaceObject.get("date").toString());
            viewAttendance.setText(checkAttendnaceObject.getList("PresentStudents").toString());



    //        attendance.setText(parseUser.getUpdatedAt() +parseUser.get("Present").toString());
     //   ParseObject attendanceObject = new ParseObject("Attendance");

/*
        if(checkAttendnaceObject.get("Date").toString().equals(curDate))
        {
            viewAttendance.setText(checkAttendnaceObject.getList("PresentStudents").toString());
        }else
        {
            viewAttendance.setText("Nothing found !");
        }

*/
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        /*
        for(int i=0;selectYear==attendanceObject.get("Year");i++)
        {
            for(int j=0;selectDepart==attendanceObject.get("Branch");j++){
                for(int k=0;curDate==checkAttendnaceObject.get("Date");k++)
                {
                  //  checkAttendnaceObject.put("PresentStudents",selItems);
                }
            }
        }

*/
        /*
        final ArrayList<HashMap<String, String>> tweetList = new ArrayList<>();
        final SimpleAdapter adapter = new SimpleAdapter(ViewAttendance.this, tweetList, android.R.layout.simple_list_item_2, new String[]{"curDate", "curPresent"}, new int[]{android.R.id.text1, android.R.id.text2});
        try {
            ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery("User");
           //parseQuery.whereContainedIn("Date", ParseUser.getCurrentUser().getList("Present"));
           parseQuery.whereEqualTo("Date","Present");
            parseQuery.findInBackground(new FindCallback<ParseObject>() {
                @Override
                public void done(List<ParseObject> objects, ParseException e) {
                    if (objects.size() > 0 && e == null) {
                        for (ParseObject tweetObject : objects) {
                            HashMap<String, String> userTweet = new HashMap<>();
                            userTweet.put("curDate", tweetObject.getString("user"));
                            userTweet.put("curPresent", tweetObject.getString("Date"));
                            tweetList.add(userTweet);

                        }

                        viewTweetsListView.setAdapter(adapter);

                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
*/

    }
}
