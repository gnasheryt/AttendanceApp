package com.gnasher.attendance;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class WelcomeActivity extends AppCompatActivity {
     private androidx.appcompat.widget.Toolbar toolbar;
     private ViewPager viewPager;
     private TabLayout tabLayout;
     private TabAdapter tabAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        /*
        TextView txt=findViewById(R.id.textView);
        Button logout=findViewById(R.id.button);
        txt.setText("Welcome !"+ ParseUser.getCurrentUser().get("username"));

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ParseUser.logOut();
                Intent in=new Intent(WelcomeActivity.this,SignUpLogin.class);
                startActivity(in);

            }
        });

         */

        setTitle("Attendance App");
        toolbar=findViewById(R.id.myToolbar);
        setSupportActionBar(toolbar);
        viewPager=findViewById(R.id.viewPager);
        tabAdapter=new TabAdapter(getSupportFragmentManager());
        viewPager.setAdapter(tabAdapter);
        tabLayout=findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager,false);


    }
}
