package com.gnasher.attendance;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

public class fetchAttendance extends AppCompatActivity {
    TextView fetchDate,fetchPresented;
    private ListView viewTweetsListView;
    String curDate;
    Calendar calendar;
    SimpleDateFormat dateFormat;
    Button checkAttendance;
    String selectedMonth,selectedSubject;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fetch);
        ParseObject fetchAttendance=new ParseObject("PresentOn");
        //fetchDate=findViewById(R.id.fetchDate);
        viewTweetsListView = findViewById(R.id.viewTweetsListView);
        ParseUser parseUser=ParseUser.getCurrentUser();
        calendar = Calendar.getInstance();
        curDate = dateFormat.getDateInstance().format(calendar.getTime());
       // fetchPresented=findViewById(R.id.fetchPresent);
       // fetchDate.setText(ParseUser.getCurrentUser().getString("date"));
       // fetchPresented.setText(ParseUser.getCurrentUser().getString("PresentOn"));
        checkAttendance=findViewById(R.id.checkAttendance);

        final Spinner month = findViewById(R.id.selectMonth);
        ArrayAdapter<CharSequence> month1 = ArrayAdapter.createFromResource(this,
                R.array.month, android.R.layout.simple_spinner_item);
        month1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        month.setAdapter(month1);
        selectedMonth=(String) month.getSelectedItem();



        final Spinner subj = findViewById(R.id.selectSub);
        ArrayAdapter<CharSequence> subjects1 = ArrayAdapter.createFromResource(this,
                R.array.subjects, android.R.layout.simple_spinner_item);
        subjects1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subj.setAdapter(subjects1);

        selectedSubject=(String)subj.getSelectedItem();


        checkAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final ArrayList<HashMap<String, String>> tweetList = new ArrayList<>();
                final SimpleAdapter adapter = new SimpleAdapter(fetchAttendance.this, tweetList, android.R.layout.simple_list_item_2, new String[]{"tweetUserName", "tweetValue"}, new int[]{android.R.id.text1, android.R.id.text2});
                try {
                    ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery("PresentOn");
                    // parseQuery.whereContainedIn("user", ParseUser.getCurrentUser().getList("fanOf"));

//                    parseQuery.whereNotContainedIn("date",ParseUser.getCurrentUser().getList("date"));
//
//                    parseQuery.findInBackground(new FindCallback<ParseObject>() {
//                        @Override
//                        public void done(List<ParseObject> objects, ParseException e) {
//
//                        }
//                    });

                    parseQuery.addAscendingOrder("date");

                    parseQuery.whereContains("date",month.getSelectedItem().toString());
                   // parseQuery.whereContains("subjects",subj.getSelectedItem());
                    parseQuery.whereEqualTo("subjects",subj.getSelectedItem());
                    parseQuery.whereNotEqualTo("date",ParseUser.getCurrentUser().getList("date"));
                    parseQuery.findInBackground(new FindCallback<ParseObject>() {
                        @Override
                        public void done(List<ParseObject> objects, ParseException e) {
                            if (objects.size() > 0 && e == null) {
                                for (ParseObject tweetObject : objects) {
                                    HashMap<String, String> userTweet = new HashMap<>();
                                    // fetchDate.setText( ParseUser.getCurrentUser().getString("date"));
                                    // fetchPresented.setText(ParseUser.getCurrentUser().getString("PresentStudents"));


                                  //  if(tweetObject.getString("subjects")==subj.getSelectedItem()) {
                                  //  if(tweetObject.getString("date")!=ParseUser.getCurrentUser().getList("date").toString()){

                                        if (tweetObject.getString("presenties") != null) {
                                            userTweet.put("tweetUserName", "Date:                                    "
                                                    +tweetObject.getString("date") +"\nLast Upadted at :\n"+ tweetObject.getUpdatedAt());
                                            userTweet.put("tweetValue", "Present:                                    "
                                                    + tweetObject.getString("presenties"));
                                        } else {
                                            userTweet.put("tweetUserName", tweetObject.getString("date"));
                                            userTweet.put("tweetValue", " Holiday ! or not found ");
                                        }
                                        tweetList.add(userTweet);
                                   // }
                                }

                                viewTweetsListView.setAdapter(adapter);

                            }
                        }
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });





/*  Only half working !!!!!!!
        try {
            ParseQuery<ParseObject> parseQuery = ParseQuery.getQuery("PresentOn");
            //  parseQuery.whereEqualTo("Date","Present");
            parseQuery.addAscendingOrder("date");
            parseQuery.findInBackground(new FindCallback<ParseObject>() {
                @Override
                public void done(List<ParseObject> objects, ParseException e) {
                    if (objects.size() > 0) {
                        if (e == null) {
                            for (ParseObject object : objects) {
                                fetchDate.setText( ParseUser.getCurrentUser().getString("date"));
                                fetchPresented.setText(ParseUser.getCurrentUser().getString("PresentStudents"));
                                // viewDate.setText(ParseUser.getCurrentUser().get("date").toString());
                                // viewAttendance.setText(checkAttendnaceObject.getList("PresentStudents").toString());
                                // checkAttendnaceObject.getList("PresentStudents").toString();
                            }
                        }
                    }
                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }*/

    }
}
